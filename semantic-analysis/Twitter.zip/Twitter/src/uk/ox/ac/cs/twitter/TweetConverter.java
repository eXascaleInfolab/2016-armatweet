package uk.ox.ac.cs.twitter;

import java.io.File;
import java.io.FileFilter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.FileReader;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;

public class TweetConverter {
	protected static final int FLUSH_BUFFER_SIZE = 10000;
	protected static final int NUMBER_OF_THREADS = 6;
	
	protected final PrintWriter m_output;
	protected final Prefixes m_prefixes;
	protected final String m_prefixesString;
	protected final Map<Integer, OutputWriter> m_outputWritersByDay;
	protected final AtomicInteger m_nextQuadID;
	protected final File m_outputDirectory;
	protected final File[] m_inputFiles;
	protected int m_nextInputFileIndex;
	
	public TweetConverter(PrintWriter output, File outputDirectory, File[] inputFiles) {
		m_output = output;
		m_prefixes = new Prefixes();
		m_prefixes.declareSemanticWebPrefixes();
		m_prefixes.declarePrefix("ast:", Namespaces.ARMASUISSE_TWEET_NS);
		m_prefixes.declarePrefix("asq:", Namespaces.ARMASUISSE_QUAD_NS);
		m_prefixes.declarePrefix("aso:", Namespaces.ARMASUISSE_ONTO_NS);
		m_prefixes.declarePrefix("dbr:", Namespaces.DBPEDIA_RESOURCE_NS);
		m_prefixes.declarePrefix("dbo:", Namespaces.DBPEDIA_ONTO_NS);
		m_prefixes.declarePrefix("wno:", Namespaces.WORDNET_ONTO_NS);
		m_prefixes.declarePrefix("wnr:", Namespaces.WORDNET_RESOURCE_NS);
		TurtleWriter turtleWriter = new TurtleWriter(m_prefixes);
		turtleWriter.printPrefixes();
		m_prefixesString = turtleWriter.getBufferContents(); 
		m_outputWritersByDay = new HashMap<Integer, OutputWriter>();
		m_nextQuadID = new AtomicInteger(1);
		m_outputDirectory = outputDirectory;
		m_inputFiles = inputFiles.clone();
		m_nextInputFileIndex = 0;
	}
	
	protected String toString(int number) {
		if (number < 10)
			return "0" + String.valueOf(number);
		else
			return String.valueOf(number);
	}
	
	protected synchronized OutputWriter getOutputWriter(int year, int month, int day) throws Exception {
		Integer key = Integer.valueOf((year * 23 + month) * 41 + day);
		OutputWriter outputWriter = m_outputWritersByDay.get(key);
		if (outputWriter == null) {
			outputWriter = new OutputWriter(new FileWriter(new File(m_outputDirectory, "tweets." + year + "-" + toString(month) + "-" + toString(day) + ".ttl")));
			outputWriter.m_writer.append(m_prefixesString);
			m_outputWritersByDay.put(key, outputWriter);
		}
		return outputWriter;
	}

	protected synchronized void close() throws Exception {
		for (OutputWriter outputWriter : m_outputWritersByDay.values()) {
			outputWriter.m_lock.lock();
			try {
				outputWriter.m_writer.close();
			}
			finally {
				outputWriter.m_lock.unlock();
			}
		}
		m_outputWritersByDay.clear();
	}
	
	protected synchronized int getNextInputFileIndex() {
		if (m_nextInputFileIndex >= m_inputFiles.length)
			return -1;
		else
			return m_nextInputFileIndex++;			
	}
	
	protected static class OutputWriter {
		protected final Writer m_writer;
		protected final Lock m_lock;
		
		public OutputWriter(Writer writer) {
			m_writer = writer;
			m_lock = new ReentrantLock();
		}
	}
	
	protected static class QuadIDDispenser {
		protected final AtomicInteger m_nextQuadID;
		protected int m_nextID;
		protected int m_afterLastID;
		
		QuadIDDispenser(AtomicInteger nextQuadID) {
			m_nextQuadID = nextQuadID;
			m_nextID = m_afterLastID = 0;
		}
		
		public int nextQuadID() {
			if (m_nextID == m_afterLastID) {
				m_nextID = m_nextQuadID.getAndAdd(1000);
				m_afterLastID = m_nextID + 1000;
			}
			return m_nextID++;
		}
	}
	
	protected static class OutputChunk {
		protected final TurtleWriter m_turtleWriter;
		protected final OutputWriter m_outputWriter;
		
		public OutputChunk(Prefixes prefixes, OutputWriter outputWriter) {
			m_turtleWriter = new TurtleWriter(prefixes);
			m_outputWriter = outputWriter;
		}
		
		public void tryFlush() throws Exception {
			if (m_outputWriter.m_lock.tryLock())
				try {
					m_turtleWriter.write(m_outputWriter.m_writer);
				}
				finally {
					m_outputWriter.m_lock.unlock();
				}
		}

		public void flush() throws Exception {
			m_outputWriter.m_lock.lock();
			try {
				m_turtleWriter.write(m_outputWriter.m_writer);
			}
			finally {
				m_outputWriter.m_lock.unlock();
			}
		}

	}
	
	protected class Worker extends Thread {
		protected final Map<Integer, OutputChunk> m_outputChunksByDay;
		protected final QuadIDDispenser m_dispenser;
		
		public Worker() {
			m_outputChunksByDay = new HashMap<Integer, OutputChunk>();
			m_dispenser = new QuadIDDispenser(m_nextQuadID);
		}
		
		protected boolean isMoreSpecific(String specific, String general) {
			return general == null || general.equals(specific); 
		}
		
		protected boolean isMoreSpecific(String subjectSpecific, String predicateSpecific, String objectSpecific, String locationSpecific, String subjectGeneral, String predicateGeneral, String objectGeneral, String locationGeneral) {
			return isMoreSpecific(subjectSpecific, subjectGeneral) && isMoreSpecific(predicateSpecific, predicateGeneral) && isMoreSpecific(objectSpecific, objectGeneral) && isMoreSpecific(locationSpecific, locationGeneral);
		}
		
		protected void addQuad(List<String> quadS, List<String> quadP, List<String> quadO, List<String> quadL, String subject, String predicate, String object, String location) {
			for (int index = quadS.size() - 1; index >= 0; --index) {
				if (isMoreSpecific(quadS.get(index), quadP.get(index), quadO.get(index), quadL.get(index), subject, predicate, object, location))
					return;
				if (isMoreSpecific(subject, predicate, object, location, quadS.get(index), quadP.get(index), quadO.get(index), quadL.get(index))) {
					quadS.remove(index);
					quadP.remove(index);
					quadO.remove(index);
					quadL.remove(index);
				}
			}
			quadS.add(subject);
			quadP.add(predicate);
			quadO.add(object);
			quadL.add(location);
		}
		
		protected void processFile(File file, int fileNumber) throws Exception {
			Calendar calendar = GregorianCalendar.getInstance(); 
			long start = System.currentTimeMillis();
			FileReader<GenericRecord> fileReader = DataFileReader.openReader(file, new GenericDatumReader<GenericRecord>());
			try {
				int tweets = 0;
				int tweetsWithEntities = 0;
				Set<String> predicatesSeen = new HashSet<String>();
				Set<String> entitiesSeen = new HashSet<String>();
				List<String> quadS = new ArrayList<String>();
				List<String> quadP = new ArrayList<String>();
				List<String> quadO = new ArrayList<String>();
				List<String> quadL = new ArrayList<String>();
				List<String> otherEntities = new ArrayList<String>();
				List<String> otherPredicates = new ArrayList<String>();
				for (GenericRecord  update : fileReader) {
					++tweets;
					predicatesSeen.clear();
					entitiesSeen.clear();
					quadS.clear();
					quadP.clear();
					quadO.clear();
					quadL.clear();
					otherPredicates.clear();
					otherEntities.clear();
					// Parse quintuples first
					String quintuples = update.get("triples_linked_spotlight").toString();
					int subjectStart = 0;
					int predicateDelimiter;
					int objectDelimiter;
					int locationDelimiter;
					int timeDelimiter;
					while (subjectStart != -1 && (predicateDelimiter = quintuples.indexOf('\t', subjectStart)) != -1 && (objectDelimiter = quintuples.indexOf('\t', predicateDelimiter + 1)) != -1 && (locationDelimiter = quintuples.indexOf('\t', objectDelimiter + 1)) != -1 && (timeDelimiter = quintuples.indexOf('\t', locationDelimiter + 1)) != -1) {
						int nextSubjectDelimiter = quintuples.indexOf('\t', timeDelimiter + 1);
						String subjectURIOrQuestionmark = quintuples.substring(subjectStart, predicateDelimiter);
						String predicateURIOrQuestionmark = quintuples.substring(predicateDelimiter + 1, objectDelimiter);
						String objectURIOrQuestionmark = quintuples.substring(objectDelimiter + 1, locationDelimiter);
						String locationURIOrQuestionmark = quintuples.substring(locationDelimiter + 1, timeDelimiter);
						String time = (nextSubjectDelimiter == -1 ? quintuples.substring(timeDelimiter + 1, quintuples.length()) : quintuples.substring(timeDelimiter + 1, nextSubjectDelimiter));
						String subject;
						String predicate;
						String object;
						String location;
						if ("?".equals(subjectURIOrQuestionmark))
							subject = null;
						else {
							subject = subjectURIOrQuestionmark.substring(1, subjectURIOrQuestionmark.length() - 1);
							entitiesSeen.add(subject);
						}
						if ("?".equals(predicateURIOrQuestionmark))
							predicate = null;
						else {
							predicate = predicateURIOrQuestionmark.substring(1, predicateURIOrQuestionmark.length() - 1);
							predicatesSeen.add(predicate);
						}
						if ("?".equals(objectURIOrQuestionmark))
							object = null;
						else {
							object = objectURIOrQuestionmark.substring(1, objectURIOrQuestionmark.length() - 1);
							entitiesSeen.add(object);
						}
						if ("?".equals(locationURIOrQuestionmark))
							location = null;
						else {
							location = locationURIOrQuestionmark.substring(1, locationURIOrQuestionmark.length() - 1);
							entitiesSeen.add(location);
						}
						if ("?".equals(time))
							time = null;
						addQuad(quadS, quadP, quadO, quadL, subject, predicate, object, location);
						if (nextSubjectDelimiter == -1)
							subjectStart = -1;
						else
							subjectStart = nextSubjectDelimiter + 1;
					}
					// Parse entities
					String entities = update.get("entities").toString();
					int surfaceFormStart = 0;
					int surfaceTypeDelimiter;
					int typeDelimiter;
					int uriDelimiter;
					int startOffsetDelimiter;
					int endOffsetDelimiter;
					while (surfaceFormStart != -1 && (surfaceTypeDelimiter = entities.indexOf('\t', surfaceFormStart)) != -1 && (typeDelimiter = entities.indexOf('\t', surfaceTypeDelimiter + 1)) != -1 && (uriDelimiter = entities.indexOf('\t', typeDelimiter + 1)) != -1 && (startOffsetDelimiter = entities.indexOf('\t', uriDelimiter + 1)) != -1 && (endOffsetDelimiter = entities.indexOf('\t', startOffsetDelimiter + 1)) != -1) {
						int nextSurfaceFormDelimiter = entities.indexOf('\t', endOffsetDelimiter + 1);
						char type = entities.charAt(typeDelimiter + 1);
						String uri = entities.substring(uriDelimiter + 2, startOffsetDelimiter - 1);
						switch (type) {
						case 'V':
							if (predicatesSeen.add(uri))
								otherPredicates.add(uri);
							break;
						case '*':
							if (entitiesSeen.add(uri))
								otherEntities.add(uri);
							break;
						default:
							throw new Exception("Invalid type '" + type +"'.");
						}
						if (nextSurfaceFormDelimiter == -1)
							surfaceFormStart = -1;
						else
							surfaceFormStart = nextSurfaceFormDelimiter + 1;
					}
					// Write the quad if it contains at least one entity.
					if (!entitiesSeen.isEmpty()) {
						++tweetsWithEntities;
						calendar.setTimeInMillis(((Long)update.get("createdAtAsLong")).longValue());
						OutputChunk outputChunk = getOutputChunk(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH));
						// Retrieve the remaining parts
						String id = Namespaces.ARMASUISSE_TWEET_NS + update.get("id").toString();
						String createdAt = update.get("createdAt").toString();
						String text = update.get("text").toString();
						// Write them
						outputChunk.m_turtleWriter.print(id, Namespaces.RDF_NS + "type", Namespaces.ARMASUISSE_ONTO_NS + "Tweet");
						outputChunk.m_turtleWriter.print(id, Namespaces.ARMASUISSE_ONTO_NS + "createdAt", createdAt, Namespaces.XSD_NS + "dateTime");
						outputChunk.m_turtleWriter.print(id, Namespaces.ARMASUISSE_ONTO_NS + "hasText", text, Namespaces.XSD_NS + "string");
						if (!otherEntities.isEmpty())
							for (String uri : otherEntities)
								outputChunk.m_turtleWriter.print(id, Namespaces.ARMASUISSE_ONTO_NS + "tweetEntity", uri);
						if (!otherPredicates.isEmpty())
							for (String uri : otherPredicates)
								outputChunk.m_turtleWriter.print(id, Namespaces.ARMASUISSE_ONTO_NS + "tweetPredicate", uri);
						// Write quads last so that we don't break the flow of Turtle.
						for (int quadIndex = 0; quadIndex < quadS.size(); ++quadIndex) {
							String subject = quadS.get(quadIndex);
							String predicate = quadP.get(quadIndex);
							String object = quadO.get(quadIndex);
							String location = quadL.get(quadIndex);
							String quadID = Namespaces.ARMASUISSE_QUAD_NS + m_dispenser.nextQuadID();
							outputChunk.m_turtleWriter.print(id, Namespaces.ARMASUISSE_ONTO_NS + "tweetQuad", quadID);
							if (subject != null)
								outputChunk.m_turtleWriter.print(quadID, Namespaces.ARMASUISSE_ONTO_NS + "quadSubject", subject);
							if (predicate != null)
								outputChunk.m_turtleWriter.print(quadID, Namespaces.ARMASUISSE_ONTO_NS + "quadPredicate", predicate);
							if (object != null)
								outputChunk.m_turtleWriter.print(quadID, Namespaces.ARMASUISSE_ONTO_NS + "quadObject", object);
							if (location != null)
								outputChunk.m_turtleWriter.print(quadID, Namespaces.ARMASUISSE_ONTO_NS + "quadLocation", location);
						}
						outputChunk.m_turtleWriter.flush();
						if (outputChunk.m_turtleWriter.getBufferSize() > FLUSH_BUFFER_SIZE)
							outputChunk.tryFlush();
					}
				}
				long duration = System.currentTimeMillis() - start;
				synchronized (m_output) {
					m_output.println(fileNumber + ": Converted '" + file.toString() + ": " + tweetsWithEntities + " / " + tweets + "  [" + duration + " ms]");
					m_output.flush();
				}
			}
			finally {
				fileReader.close();
			}
		}

		public OutputChunk getOutputChunk(int year, int month, int day) throws Exception {
			Integer key = Integer.valueOf((year * 23 + month) * 41 + day);
			OutputChunk outputChunk = m_outputChunksByDay.get(key);
			if (outputChunk == null) {
				outputChunk = new OutputChunk(m_prefixes, getOutputWriter(year, month, day));
				m_outputChunksByDay.put(key, outputChunk);
			}
			return outputChunk;
		}

		public void run() {
			try {
				int inputFileIndex = getNextInputFileIndex();
				while (inputFileIndex != -1) {
					processFile(m_inputFiles[inputFileIndex], inputFileIndex);
					inputFileIndex = getNextInputFileIndex();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				for (OutputChunk outputChunk : m_outputChunksByDay.values())
					try {
						outputChunk.flush();
					}
					catch (Exception e) {
						e.printStackTrace();
					}
				m_outputChunksByDay.clear();
			}
		}
	}

	public static void main(String[] args) throws Exception {
		String datasetName = "Data-05";
		
		File inputDirectory = new File("/Volumes/Mentat/" + datasetName + "/avro");
		File outputDirectory = new File("/Volumes/Mentat/" + datasetName + "/ttl");
		File[] inputFiles = inputDirectory.listFiles(new FileFilter() {
			public boolean accept(File file) {
				return file.getName().endsWith(".avro");
			}
		});
		PrintWriter output = new PrintWriter(System.out);
		try {
			if (inputFiles == null)
				output.println("No input files were given!");
			else {
				long start = System.currentTimeMillis();
				TweetConverter tweetConverter = new TweetConverter(output, outputDirectory, inputFiles);
				Worker[] workers = new Worker[NUMBER_OF_THREADS];
				for (int index = 0; index < NUMBER_OF_THREADS; ++index) {
					workers[index] = tweetConverter.new Worker();
					workers[index].start();
				}
				for (int index = 0; index < NUMBER_OF_THREADS; ++index)
					workers[index].join();
				tweetConverter.close();
				long duration = System.currentTimeMillis() - start;
				output.println("Converted " + inputFiles.length + " files in " + duration + " ms.");
			}
		}
		finally {
			output.close();
		}
	}
}
