package uk.ox.ac.cs.twitter;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

public class TurtleWriter {
	protected final static String CRLF = System.getProperty("line.separator");
	
	protected final Prefixes m_prefixes;
	protected final StringBuilder m_buffer;
	protected String m_lastSubject;
	protected String m_lastPredicate;
	
	public TurtleWriter(Prefixes prefixes) {
		m_prefixes = prefixes;
		m_buffer = new StringBuilder();
		m_lastSubject = null;
		m_lastPredicate = null;
	}
	
	public void printPrefixes() {
		for (Map.Entry<String, String> entry : m_prefixes.getPrefixNameToPrefixIRIMappings()) {
			m_buffer.append("@prefix ");
			m_buffer.append(entry.getKey());
			m_buffer.append(" <");
			m_buffer.append(entry.getValue());
			m_buffer.append("> .");
			m_buffer.append(CRLF);
		}
		m_buffer.append(CRLF);
	}
	
	protected void printSubjectPredicate(String subjectIRI, String predicateIRI) {
		if (m_lastSubject == null) {
			m_prefixes.abbreviateIRI(subjectIRI, m_buffer);
			m_buffer.append(' ');
			m_buffer.append(m_prefixes.abbreviateIRI(predicateIRI));
			m_buffer.append(' ');
		}
		else {
			if (subjectIRI.equals(m_lastSubject)) {
				if (predicateIRI.equals(m_lastPredicate))
					m_buffer.append(" , ");
				else {
					m_buffer.append(" ;");
					m_buffer.append(CRLF);
					m_buffer.append("    ");
					m_prefixes.abbreviateIRI(predicateIRI, m_buffer);
					m_buffer.append(' ');
				}
			}
			else {
				m_buffer.append(" .");
				m_buffer.append(CRLF);
				m_prefixes.abbreviateIRI(subjectIRI, m_buffer);
				m_buffer.append(' ');
				m_prefixes.abbreviateIRI(predicateIRI, m_buffer);
				m_buffer.append(' ');
			}
		}
		m_lastSubject = subjectIRI;
		m_lastPredicate = predicateIRI;
	}
	
	public void print(String subjectIRI, String predicateIRI, String objectIRI) {
		printSubjectPredicate(subjectIRI, predicateIRI);
		m_prefixes.abbreviateIRI(objectIRI, m_buffer);
	}

	public void print(String subjectIRI, String predicateIRI, String objectValue, String objectValueDatatypeIRI) {
		printSubjectPredicate(subjectIRI, predicateIRI);
		m_buffer.append('"');
		int length = objectValue.length();
		for (int index = 0; index < length; ++index) {
			char c = objectValue.charAt(index);
			switch (c) {
			case '"':
				m_buffer.append("\\\"");
				break;
			case '\\':
				m_buffer.append("\\\\");
				break;
			case '\t':
				m_buffer.append("\\t");
				break;
			case '\r':
				m_buffer.append("\\r");
				break;
			case '\n':
				m_buffer.append("\\n");
				break;
			case '\b':
				m_buffer.append("\\b");
				break;
			case '\f':
				m_buffer.append("\\f");
				break;
			default:
				m_buffer.append(c);
				break;
			}
		}
		m_buffer.append('"');
		if (!(Namespaces.XSD_NS + "string").equals(objectValueDatatypeIRI)) {
			m_buffer.append("^^");
			m_prefixes.abbreviateIRI(objectValueDatatypeIRI, m_buffer);
		}
	}

	public int getBufferSize() {
		return m_buffer.length();
	}
	
	public void flush() {
		if (m_lastSubject != null) {
			m_buffer.append(" .");
			m_buffer.append(CRLF);
			m_lastSubject = m_lastPredicate = null;
		}
	}

	public void write(Writer writer) throws IOException {
		writer.append(m_buffer);
		m_buffer.delete(0, m_buffer.length());
	}
	
	public String getBufferContents() {
		return m_buffer.toString();
	}
}
